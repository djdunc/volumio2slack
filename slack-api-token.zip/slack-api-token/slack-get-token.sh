#!/usr/bin/env bash

set -o allexport

# add in your settings into the 3 variables below
client_id='THE CLIENT ID FOR THE SLACK APP YOU HAVE CREATED'
secret='AND THE RESPECTIVE SECRET'
scope='ENTER THE SLACK WORKSPACE NAME HERE'

# function to retrieve token
function api {
  oauth2_url='https://slack.com/oauth/authorize'
  oauth_auth='https://slack.com/api/oauth.access'
  redirect_uri="http://localhost:8080"
 
  if [ -z "$SLACK_TOKEN" ]; then

  	echo "Open this link your browser: $oauth2_url?client_id=$client_id&secret=$secret&scope=$scope&redirect_uri=$redirect_uri"
    read -p "Enter the code from browser here : " temp_code

    echo
    echo "Requesting your token from Slack"
    response=$(http -f POST $oauth_auth client_id=$client_id client_secret=$secret code=$temp_code redirect_uri=$redirect_uri)
    echo    

    SLACK_TOKEN=$(echo $response | jq -r '.access_token')
    echo "Your Slack oAuth Token is: $SLACK_TOKEN"
    export SLACK_TOKEN=$SLACK_TOKEN
    echo 
  else
    #echo "Your Slack oAuth Token is: $SLACK_TOKEN"
    echo
  fi
}

# run server.js (assumes node is available) and then calls api function
if [ -z "$SLACK_TOKEN" ]; then
  node server.js &
  api
else
  echo "Didn't try to get token."
fi

set +o allexport






