#!/usr/bin/env node

const express = require('express')
const app = express()
 
app.get('/', function (req, res) {
   res.send('Please add this code when requested on the terminal: <b>' + req.query.code + '</b>')
   process.exit(1)
})
 
app.listen(8080)


